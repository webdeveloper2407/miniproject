<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Home</title>
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="5000">
      <img src="https://www.karnatakatourism.org/wp-content/uploads/2021/01/india-national-tourism-day.jpg" class="d-block w-100" alt="..." width="1570px" height="750px">
    </div>
    <div class="carousel-item" data-bs-interval="5000">
      <img src="https://images.unsplash.com/photo-1619120238346-978e07731e77?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fA%3D%3D&w=1000&q=80" class="d-block w-100" alt="..." width="1570px" height="750px">
    </div>
    <div class="carousel-item" data-bs-interval="5000">
      <img src="https://d2rdhxfof4qmbb.cloudfront.net/wp-content/uploads/20180510163557/iStock-827065008-1024x712.jpg" class="d-block w-100" alt="..." width="1570px" height="750px">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<div class="main">
    <ul>
      <ul class="list">

          <li class="logo"><a href="admin.html"><img src="Untitled_design-removebg-preview.png" alt="Logo" style="margin-top:20px;width:342px;height:78px;object-fit:cover;object-position:50% 50%"></a></li>
          <div class="search">
            <form method="POST" action="info.php">
              <input type="text" name="search_p" placeholder="Search.." size="50"; style="margin-top:50px;margin-left:-68px;">

              <input type="image" name="submit_p" src="search_icon.png" alt="Search image" style="width:22;height:22;margin-top:110px;margin-left:300px;">
            </form>
          </div>
      </ul>
      <ul class="nav-area" style="margin-left:18px;margin-top:35px;">
        <li class="active-menu"><a href="admin.php">Home</a></li>
        <li><a href="destination.html">Destination</a></li>
        <li><a href="gallary.html">Gallery</a></li>
        <li><a href="feedback.html">Feedback</a></li>
        <li><a class="float-right" href="logout.php">Logout</a></li>
      </ul>
    </ul>
</div>
<div class="title">
  <h1>Pack Your <span>Bags</span></h1>
  <h2>Welcome <span><?php echo $_SESSION['username'];?></span></h2>
</div>
<img src="images-removebg-preview.png" class="img_1 " style="z-index: 0;position:relative;;top: 220px;left: 700px;">
<img src="https://www.texasreview.in/images/plane.png" class="spin" align="center" style=" object-position:center;"/>
<div class="quote">
  <h1>A <span>Journey</span>of thousand miles must begin with a single tap</h1>
</div>
<div class="about" id="aboutus">
  <h2 style="padding:10px;">Abouts Us</h2>
  <p style="padding:10px;">Welcome to Pack Your Bags! Pack Your Bags is an online platform for booking tickets in a genuine and friendly manner. Allows the user to search availability, compare prices and book tickets on the platform by providing details such as destination, arrival-departure datesetc. The platform also provides information on holiday packages.We are a little family that could. Years ago, when our son was still a bun in the oven, we knew that life didn’t need to be ordinary. Life could be a grand adventure. We believed in our dreams and neither the naysayers nor our serious inner voices could have stopped us. And today, we live in the India, work online, travel often and, like in the photo above. We can’t imagine living a “regular” nine-to-five life ever again..</p>
  <section class="testimonials" style="text-align: center;color:#ff9800">
    <div class="container">
      <h1>Our Clients</h1>
      <div class="row">
        <div class="col-md-4 text-center">
          <div class="profile">
            <img src="model2.jpg" class="user">
              <blockquote>It was overall a nice experience traveling to Goa and got a good place to stay.
                Tour Guide was very cooperative & manageable & hotels were also good
              It was a very Good trip planned by the agent.</blockquote>
                <h3>Avinash Kr <span>From Mumbai</span></h3>
          </div>
      </div>
      <div class="col-md-4 text-center">
        <div class="profile">
          <img src="model.jpeg" class="user">
            <blockquote>Wonderful Trip Hotels were great except Katra Residency apart from this
              I liked the services provided cab driver was great very cooperative,
              friendly in nature Thanks to Travel Triangle for organizing such a lovely
              trip Srinagar is very beautiful Kashmir is heaven like destination</blockquote>
              <h3>Muralidhatran <span>From Bengaluru</span></h3>
          </div>
        </div>
        <div class="col-md-4 text-center">
          <div class="profile">
            <img src="model3.jpg" class="user">
              <blockquote>Had Fabulous trip well managed, well coordinated and everyone were
                very cooperative and friendly.The vacation was wonderful and I cannot say
                thank you enough!! It was good resort for us.</blockquote>
                <h3>Deepika <span>From Hyderabad</span></h3>
            </div>
          </div>
      </div>
    </div>
  </section>
   <footer>
      <br></br>
      <a href="https://www.facebook.com/"> <img src=https://cdn3.iconfinder.com/data/icons/capsocial-round/500/facebook-512.png height="50px" width="50px"> </a>
      <a href="https://www.instagram.com/"> <img src=https://thumbs.dreamstime.com/b/instagram-icon-logo-vector-editable-vector-illustration-instagram-popular-social-media-icon-solid-flat-transparent-219801448.jpg height="50px" width="50px"> </a>
      <a href="https://twitter.com/"> <img src=https://cdn-icons-png.flaticon.com/512/124/124021.png height="50px" width="50px"> </a>
      <p> <b> For more about us click here.<br>
        <div class="pages">
            <h3 style="padding:10px;">Pages</h3>
            <a href="#aboutus">About Us</a>|
            <a href="destination.html">Destination</a>|
            <a href="gallary.html">Gallary</a>|
            <a href="login.html">Login</a>|
            <a href="signin.html">Sign Up</a>
        </div>
        <div class="doc">
            <h3 style="padding:10px;">Documents</h3>
            <a href="">Privacy Policy</a>|
            <a href="">Terms of Use</a>|
            <a href="feedback.html">Refund Policy</a>
        </div>
        <br></br>
    </p>
    <hr>
    <p style="padding:10px;">Copyright &copy; 2022 PackYourBags.All rights reserved</p>
    <p style="padding:10px;">Stanley College Of Engineering And Technology For Women</p>
    <p style="padding:10px;">Abids , Hyderabad</p>
   </footer>
</div>
  </body>
</html>
