<?php
$Username = $_POST['Username']
     $Password = $_POST['Password']
     $Email = $_POST['Email']
     $City = $_POST['City']
     $Phone = $_POST['Phone']

     $conn = new mysqli('localhost','root','','mysql');
     if($conn->connect_error){
       die('connection Failed :' .$conn->connect_error);
     }
     else{
       $stmt = $conn->prepare("insert into customer(Username,Password,Email,City,Phone)
       values(?,?,?,?,?)");
       $stmt->bind_param("ssssi",$Username,$Email,$Password,$City,$Phone);
       $stmt->execute();
       echo "signup successfully..";
       $stmt->close();
       $conn->close();
     }
?>
