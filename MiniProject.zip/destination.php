<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=divice-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="destination.css">
	<title>Destinations</title>
	<style type="text/css">
		.container .box .name-text input{
			position: relative;
			display: none;
			background: transparent;
			border: 1px solid #fff;
			top: -20px;
			color: #fff;
			text-decoration: none;
			transition: 0.6s ease;
			text-align: center;
		}
		.btn{
			padding: 5px 40px;
		}
		.btn1{
			margin: 0px -20px;
			padding: 5px 40px;
		}
		.btn2{
			padding: 5px 60px;
		}
		.btn3{
			padding: 5px 37px;
			margin: 0px -2px;
		}
		.btn4{
			padding: 5px 50px;
		}
		.btn5{
			padding: 5px 25px;
		}
		.container .box:hover .name-text input{
			display: block;
			top: -20px;
		}
		.container .box .name-text input:hover{
			background-color: #fff;
		    color: #000;
		}
	</style>
</head>
<body>
	<h1 class="heading">Popular Destinations</h1>
	<div class="main">
	    <ul>
	      <ul class="list">

	          <li class="logo"><a href="admin.html"><img src="Untitled_design-removebg-preview.png" alt="Logo" style="margin-top:20px;width:342px;height:78px;object-fit:cover;object-position:50% 50%"></a></li>
	          <div class="search">
	            <form method="POST" action="info.php">
	              <input type="text" name="search_p" placeholder="Search.." size="50"; style="margin-top:50px;margin-left:-88px;">

	              <input type="image" name="submit_p" src="search_icon.png" alt="Search image" style="width:22;height:22;margin-top:110px;margin-left:320px;">
	            </form>
	          </div>
	      </ul>
	      <ul class="nav-area" style="margin-left:18px;margin-top:35px;">
	        <li class="active-menu"><a href="admin.html">Home</a></li>
	        <li><a href="destination.html">Destination</a></li>
	        <li><a href="gallary.html">Gallery</a></li>
	        <li><a href="feedback.html">Feedback</a></li>

	      </ul>
	    </ul>
	</div>
	<div class="container">
		<div class="box">
			<div class="imgBox">
				<img src="http://s3.amazonaws.com/authorstream/content/234407_633876234418773410.jpg" alt="Goa Image" style="width: 1500px;height: 270px;">
			</div>
			<div class="name-text name-pading1 top1">
				<h1>Goa</h1>
				<form method="POST" action="info.php">
					<a href="goa.html">visit</a>
				</form>
			</div>
		</div>
		<div class="box">
			<div class="imgBox">
				<img src="https://i.pinimg.com/originals/58/42/11/58421157f2cd479ff76529f3117d684f.jpg" alt="Russia Image" style="width: 1500px;height: 270px;">
			</div>
			<div class="name-text name-pading2 top1">
				<h1>Kerala</h1>
				<form method="POST" action="info.php">
					<a href="kerala.html">visit</a>
				</form>
			</div>
		</div>
		<div class="box">
			<div class="imgBox">
				<img src="https://globalyodel-wpengine.netdna-ssl.com/wp-content/uploads/2013/08/Jaipur-Rajasthan_Harsh-Pareek_Global-Yodel-3.jpg" alt="Rajasthan Image" style ="width:1500px;height:270px">
			</div>
			<div class="name-text name-pading3 top1">
				<h1>Rajasthan</h1>
				<form method="POST" action="info.php">
					<a href="rajasthan.html">visit</a>
				</form>
			</div>
		</div>
    <div class="box">
			<div class="imgBox">
				<img src="https://www.travelholicq.com/wp-content/uploads/2018/01/Sonamarg.jpg" alt="Jammu&kashmir Image" style="width:1800px;height:270px">
			</div>
			<div class="name-text name-pading5 top2">
				<h1>Jammu&kashmir</h1>
				<form method="POST" action="info.php">
		      <a href="jandk.html">visit</a>
				</form>
			</div>
	  </div>
		<div class="box">
			<div class="imgBox">
				<img src="https://travelomaxx.com/wp-content/uploads/2016/12/8.jpg" alt="Andaman&Nicobar Image" style="width:1800px;height:270px">
			</div>
			<div class="name-text name-pading6 top2">
				<h1>Andaman&nicobar</h1>
				<form method="POST" action="info.php">
					<a href="aandn.html">visit</a>
				</form>
			</div>
		</div>
	</div>
</body>
</html>
